/* WiFi-Control-Car(softAP) */



//
//                       _oo0oo_
//                      o8888888o
//                      88" . "88
//                      (| -_- |)
//                      0\  =  /0
//                    ___/`---'\___
//                  .' \\|     |// '.
//                 / \\|||  :  |||//  \
//                / _||||| -:- |||||-  \
//               |   | \\\  -  /// |   |
//               | \_|  ''\---/''  |_/ |
//               \  .-\__  '-'  ___/-. /
//             ___'. .'  /--.--\  `. .'___
//          ."" '<  `.___\_<|>_/___.' >' "".
//         | | :  `- \`.;`\ _ /`;.`/ - ` : | |
//         \  \ `_.   \_ __\ /__ _/   .-` /  /
//     =====`-.____`.___ \_____/___.-`___.-'=====
//                       `=---='
//
//
//     ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//
//               佛祖保佑         永无BUG
//
//
//



#include <WiFi.h>
#include <WebServer.h>
#include <SPIFFS.h>
#include <WebSocketsServer.h>
#include <ArduinoJson.h>

#include <Arduino.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ESP32Servo.h>

#include <string.h>


const char myssid[] = "asdrf1236";
const char mypass[] = "810114514";
const char Akssid[] = "ak-gakusei3";
const char Akpass[] = "WeWillMakeYouHappy";

const IPAddress ip(192,168,30,3);
const IPAddress subnet(255,255,255,0);
const char *CACHE_CONTROL="no-store,max-age=0";







String data ;
int int_payload ;
uint8_t * rawdata;




void listDir(fs::FS &fs, const char * dirname, uint8_t levels){
    Serial.printf("Listing directory: %s\r\n", dirname);

    File root = fs.open(dirname);
    if(!root){
        Serial.println("- failed to open directory");
        return;
    }
    if(!root.isDirectory()){
        Serial.println(" - not a directory");
        return;
    }

    File file = root.openNextFile();
    while(file){
        if(file.isDirectory()){
            Serial.print("  DIR : ");
            Serial.println(file.name());
            if(levels){
                listDir(fs, file.name(), levels -1);
            }
        } else {
            Serial.print("  FILE: ");
            Serial.print(file.name());
            Serial.print("\tSIZE: ");
            Serial.println(file.size());
        }
        file = root.openNextFile();
    }
}




Servo servo;
int pos=0;


constexpr int Lmotor = 26;
constexpr int Rmotor = 32;

/*
constexpr int Lmotor = A19;
constexpr int Rmotor = A4;
*/



WebServer server(80);
WebSocketsServer webSocket = WebSocketsServer(81); // 81番ポート


  // num: クライアント番号
  // type: イベント種別
  // payload, length: 受信データとそのサイズ

//StaticJsonBuffer<200> jsonBuffer;
void webSocketEvent(uint8_t num, WStype_t type, uint8_t * payload, size_t length)
{   

    bool sw = false;
    switch(type) {
        case WStype_DISCONNECTED:
           // 切断時の処理;
            Serial.println("disconnected");
            break;
        
        case WStype_CONNECTED:
        
          //IPAddress ip = webSocket.remoteIP(num); // クライアントのIPアドレスを取得
          // 接続時の処理
            Serial.println("connected");
            Serial1.println('n');
            break;

        case WStype_TEXT:
        
          // テキストデータ受信時の処理;
            //rawdata = payload;
            
            int_payload = atoi((const char *)payload);
            Serial.printf("%s\n",payload);
            //sprintf()
            switch (int_payload){//////////////////////////////////ここから調整

				case 1:
                    //ledcWrite(0, 300);//////////////////第二引数　0から２５６までの出力
                    //ledcWrite(1, 300);
                    digitalWrite(Lmotor, HIGH);
                    digitalWrite(Rmotor, HIGH);
                    Serial.println("connected");

					
					
					break;
				
				case 2:
                    //ledcWrite(1, 255);
                    digitalWrite(Lmotor, LOW);
                    digitalWrite(Rmotor, HIGH);



				case 3:
                    digitalWrite(Lmotor, LOW);
                    digitalWrite(Rmotor, LOW);
                    //pos = 0;
           
				case 4:
                                                            
                    digitalWrite(Lmotor, HIGH);
                    digitalWrite(Rmotor, LOW);
                   // ledcWrite(0, 255);
                    //pos = 180;
     
					break;
                    
                case 5:
                    digitalWrite(Lmotor, LOW);
                    digitalWrite(Rmotor, LOW);

                    ledcWrite(0, 0);
                    ledcWrite(1, 0);
                    

					break;

				default:
					
					break;
    
    		}


            

            break;

        case WStype_BIN:
          // バイナリデータ受信時の処理;
            break;

        case WStype_ERROR:
          // エラー時の処理;
            Serial.printf("ws:error");
            break;


    }
    



   



}






const bool IS_STATION_MODE=false;



void setup()
{
    pinMode(Rmotor, OUTPUT);
    pinMode(Lmotor, OUTPUT);
/*
    ledcSetup(0,50000,8);
    ledcSetup(1,50000,8);
    ledcAttachPin(Rmotor, 0); 
    ledcAttachPin(Lmotor, 1); 
*/
    Serial.begin(115200);
    //Serial1.begin(115200,SERIAL_8N1,21,22);//rx,tx
    //Serial2.begin(115200,SERIAL_8N1,27,14);//rx,tx //pre 12,14

    servo.attach(25, 500, 2500);


    if (IS_STATION_MODE){
        //IPAddress myIP = WiFi.softAPIP();
        const IPAddress gatewayIPa(192,168,179,1);
        const IPAddress gatewayIPs(170,20,10,1);
        Serial.printf("Connecting to kousentimental\n");
        WiFi.config(ip,gatewayIPs,subnet);
        WiFi.begin("PassionClub", "asdrf1236");
        while (WiFi.status() != WL_CONNECTED){
        delay(500);
        Serial.print(".");
        }
        Serial.println();
        Serial.print("Connected, IP address: ");
        Serial.println(WiFi.localIP());



    }
    else{
        WiFi.softAP(myssid,mypass);
        delay(100);
        WiFi.softAPConfig(ip,ip,subnet);

        Serial.print("SSID: ");
        Serial.println(myssid);
        Serial.print("AP IP address: ");
        Serial.println(ip);
        Serial.println("Server start!");
    }



    digitalWrite(Rmotor, LOW);
    digitalWrite(Lmotor, LOW);
    

    server.begin();
    //ledcWrite(0, 0);
    //ledcWrite(1, 0);
    



    if (!SPIFFS.begin()) {
        Serial.println("An Error has occurred while mounting SPIFFS");
        return;
    }
 
  
    server.serveStatic("/",SPIFFS,"/",CACHE_CONTROL);
    listDir(SPIFFS,"/",0);


    webSocket.begin();
    webSocket.onEvent(webSocketEvent);

}



void loop(){
    

    //Serial.printf("%s\n",Serial2.readStringUntil('\n'));   <--これいれるとバグる！！
    //digitalWrite(Rmotor, HIGH);
    //digitalWrite(Lmotor, HIGH);
    //servo.write(180);
    //ledcWrite(0,0);
    //ledcWrite(1,0);
    server.handleClient();
    webSocket.loop();
    //Serial.printf("aaaaaaaaaaaa");
   

}